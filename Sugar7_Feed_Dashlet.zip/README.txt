'RSS/Atom Feed Dashlet'.

This dashlet is to display feed about the account on account record view.

 Installation:

- Upload the zip file in the archive with the Module Loader
- Build & Repair
- Layout add RSS/Atom Field in Accounts module.

 How to use:

- Go to the Account's Record view.
- Add RSS Dashlet.
- Input RSS/Atom URL in RSS/Atom Field.
- Display Feed about RSS/Atom Field in Feed Dashlet.

 Include:
- SimplePie library (feed parser)
  http://simplepie.org/

Copyright 2014 Masaki Fukumitsu - All rights reserved.
