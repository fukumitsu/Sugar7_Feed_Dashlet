<?php
$app_strings['LBL_DASHLET_FEED']='Feed Dashlet';
$app_strings['LBL_DASHLET_FEED_DESC']='RSS/Atom Feed Dashlet(Relate RSS/Atom Field)';
