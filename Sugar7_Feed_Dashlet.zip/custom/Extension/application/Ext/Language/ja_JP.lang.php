<?php
$app_strings['LBL_DASHLET_FEED']='RSS/Atom ダッシュレット';
$app_strings['LBL_DASHLET_FEED_DESC']='RSS/Atom フィードを表示するダッシュレット(RSS/Atomフィールドと連携)';