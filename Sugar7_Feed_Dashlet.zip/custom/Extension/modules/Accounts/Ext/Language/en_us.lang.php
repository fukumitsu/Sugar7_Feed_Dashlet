<?php
$mod_strings['LBL_FEED_URL'] = 'RSS/Atom';
